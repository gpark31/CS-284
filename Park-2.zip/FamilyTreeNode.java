package specialAssignment2;

import java.util.ArrayList;
import java.util.List;

public class FamilyTreeNode {
	// Data fields
	private String lastName;
	private List<Person> members;
	public FamilyTreeNode left;
	public FamilyTreeNode right;


	/**
     	* Constructor: instantializes a new FamilyTreeNode
     	* given a lastName
     	*/
	public FamilyTreeNode(String lastName) {
			members = new ArrayList<Person>();
        	this.lastName = lastName;
        	left = null;
        	right = null;
	}

	/**
     	* Returns the last name of the FamilyTreeNode
     	*/
	public String getLastName() {
		return lastName;
	}

	/**
     	* Returns the arraylist of members in the FamilyTreeNode
     	*/
	public List<Person> getMembers() {
		return members;
	}

	/*
	 * Returns true if there is an instance of Person in the FamilyTreeNode that has
	 * the same first and last name provided Return false otherwise
	 */
	public boolean doesFamilyMemberExist(String lastName, String firstName) {
        int i = 0;
        if(this.getLastName() != lastName) {
        	return false;
        }
		while(i < members.size()) {
        	if(members.get(i).getFirstName() == firstName) {
        		return true;
        	}
        	i++;
        }
		return false;
	}

	/**
	 * Returns true if there is an instance of Person in the FamilyTreeNode whose
	 * phone number matches the one provided Returns false otherwise
	 */
	public boolean doesNumberExist(String phoneNumber) {
        int i = 0;
        while(i < members.size()) {
        	if(members.get(i).getPhoneNumber() == phoneNumber) {
        		return true;
        	}
        	i++;
        }
        return false;
	}

	/*
	 * Adds a Person to this FamilyTreeNode
	 * Throw an exception if the last name provided does not match the last name of the FamilyTreeNode
	 */
	public void addFamilyMember(String lastName, String firstName, String phoneNumber) {
		if(this.lastName != lastName) {
			throw new IllegalArgumentException("Cannot add a family member with a different last name.");
		}
		else {
			Person p = new Person(lastName, firstName, phoneNumber);
			members.add(p);
		}
	}

	/**
	 * Adds a Person to this FamilyTreeNode
	 * Throw an exception if the last name provided does not match the last name of the FamilyTreeNode
	 */
	public void addFamilyMember(Person person) {
		if(person.getLastName() != this.lastName){
			throw new IllegalArgumentException();
		}
		else {
			members.add(person);
		}
	}

	/*
	 * Returns the phone number of the person in the family with the given phone
	 * number Returns "Does not exist." if not found
	 */
	public String getPhoneNumberOfFamilyMember(String lastName, String firstName) {
		int i = 0;
		if(this.getLastName() != lastName) {
			return "Does not exist.";
		}
		while(i < members.size()) {
        	if(members.get(i).getFirstName() == firstName) {
        		return members.get(i).getPhoneNumber();
        		}
        	
        	i++;
        }
		return "Does not exist.";
	}

	/*
	 * toString method Ex: [] [John Smith (5551234567), May Smith (5551234568),
	 * April Smith (5551234569), August Smith (5551234570)]
	 */
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("[");
		for(int i = 0; i < members.size(); i++) {
			str.append(members.get(i).getFirstName());
			str.append(" ");
			str.append(members.get(i).getLastName());
			str.append(" ");
			str.append("(");
			str.append(members.get(i).getPhoneNumber());
			str.append(")");
			if(members.size()-1 != i) {
				str.append(", ");
			}
		}
		str.append("]");
		return str.toString();
	}
}
