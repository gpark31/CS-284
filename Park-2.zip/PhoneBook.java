package specialAssignment2;

import java.util.ArrayList;
import java.lang.Character;
import java.util.HashMap;
import java.util.Map;

public class PhoneBook {
	// Data fields
	public Map<Character, BSFamilyTree> directory;

	/**
     	* Creates a new phone book with an empty directory.
     	*/
	public PhoneBook() {
		directory = new HashMap<Character, BSFamilyTree>();
		for (int i = 65; i < 91; i++) {
			directory.put((char)i, new BSFamilyTree());
		}
	}

	/*
	 * Returns the instance of BSFamilyTree at the indicated letter
	 * Must accept lowercase letters as well as uppercase letters
	 */
	public BSFamilyTree getFamilyTree(char letter) {
		if(!Character.isLetter(letter)) {
			throw new IllegalArgumentException();
		}
		return directory.get(java.lang.Character.toUpperCase(letter));
	}

	/*
	 * Adds a FamilyTreeNode to the PhoneBook
	 */
	public void addFamily(String lastName) {
		char c = lastName.charAt(0);
		BSFamilyTree t = new BSFamilyTree();
		t.addFamilyTreeNode(lastName);
		for(Map.Entry<Character, BSFamilyTree> entry: directory.entrySet()) {
			if(entry.getKey() == c)
				entry.getValue().addFamilyTreeNode(lastName);
		}
	}

	/*
	 * Adds a Person to the PhoneBook
	 * If a FamilyTreeNode with the given last name doesn't currently exist, create the FamilyTreeNode
	 */
	public void addPerson(String lastName, String firstName, String phoneNumber) {
		char c = lastName.charAt(0);
		for(Map.Entry<Character, BSFamilyTree> entry: directory.entrySet()) {
			if(entry.getValue().doesFamilyExist(lastName) && entry.getKey() == c) {
				BSFamilyTree t = new BSFamilyTree();
				t = entry.getValue();
				t.getFamilyTreeNode(lastName).addFamilyMember(lastName, firstName, phoneNumber);
				entry.setValue(t);
			}
			else if(entry.getKey() == c){
				this.addFamily(lastName);
				BSFamilyTree t = new BSFamilyTree();
				t = entry.getValue();
				t.getFamilyTreeNode(lastName).addFamilyMember(lastName, firstName, phoneNumber);
				entry.setValue(t);
			}
		}
	}

	/*
	 * Finds the phone number of a person
	 * Returns 'Does not exist.' if not found.
	 */
	public String getPhoneNumber(String lastName, String firstName) {
		for(Map.Entry<Character, BSFamilyTree> entry: directory.entrySet()) {
			if(entry.getValue().doesFamilyExist(lastName)) {
					return entry.getValue().getFamilyTreeNode(lastName).getPhoneNumberOfFamilyMember(lastName, firstName);
			}
		}
		return "Does not exist.";

	}

    	/**
     	* String representation of PhoneBook
     	*/
	public String toString() {
    	StringBuilder r = new StringBuilder();
    	for(Map.Entry<Character, BSFamilyTree> entry: directory.entrySet()) {
			r.append(entry.getKey() + "\n");
			r.append(entry.getValue().toString());
			}
    	return r.toString();
	}
}
