package specialAssignment2;

import java.util.ArrayList;
import java.util.Stack;

/**
 * BSFamilyTree creates a tree for specific families. 
 */
public class BSFamilyTree {
    //Data Fields
    private FamilyTreeNode root;

    /**
     * Constructor: constructs an empty BSFamilyTree
     */
    public BSFamilyTree() {
        root = null;
    }

    /**
     * takes in the last name and returns true if there
     * is a FamilyTreeNode with the given last name.
     */
    public boolean doesFamilyExist(String lastName) {
    	FamilyTreeNode current = root;
    	if(root == null) {
    		return false;
    	}
        if(root.getLastName() == lastName) {
        	return true;
        }
        while(current != null) {
        	int i = current.getLastName().compareTo(lastName);
        	if(i == 0) {
        		return true;
        	}
        	if(i > 0) {
        		current = current.left;
        	}
        	if(i < 0) {
        		current = current.right;
        	}
        }
        return false;
    }

    /**
     * Takes in a last name and creates a new instance of
     * FamilyTreeNode and adds it to the BSFamilyTree.
     */
    public void addFamilyTreeNode(String lastName) {
        FamilyTreeNode t = new FamilyTreeNode(lastName);
        FamilyTreeNode current = root;
        if(root == null) {
        	root = t;
        }
        else {
        	while(current != null) {
        		int i = current.getLastName().compareTo(lastName);
        		if(i == 0) {
        			return;
        		}
        		if(i > 0) {
        			if(current.left == null) {
        				current.left = t;
        			}
        			current = current.left;
        		}
        		if(i < 0) {
        			if(current.right == null){
        				current.right = t;
        			}
        			current = current.right;
        		}
        	}
        }
    }

    /**
     * Takes a last name and then finds that specific
     * family tree and then returns that FamilyTreeNode
     * If last name is not in tree, throws an exception.
     */
    public FamilyTreeNode getFamilyTreeNode(String lastName) {
          FamilyTreeNode current = root;
      
          //throw exception
          if(root == null) {
          	throw new IllegalArgumentException();
          }
          
          while(current != null) {
          	int i = current.getLastName().compareTo(lastName);
          	if(i == 0) {
          		return current;
          	}
          	if(i > 0) {
          		current = current.left;
          	}
          	if(i < 0) {
          		current = current.right;
          	}
          }
         throw new IllegalArgumentException();
    }

    /**
     * Returns true if the input phone number exists in the BSFamilyTree
     * false otherwise.
     */
    private boolean doesNumberExistHelper(FamilyTreeNode current, String phoneNumber) {
        while(current != null) {
        	if(current.doesNumberExist(phoneNumber)) {
            	return true;
            }
        	if(current.left != null) {
        		if(current.left.doesNumberExist(phoneNumber)) {
        			return true;
        		}
        	}
        	if(current.right != null) {
        		if(current.right.doesNumberExist(phoneNumber)) {
        			return true;
        		}
        	}
        	return doesNumberExistHelper(current.right, phoneNumber) || doesNumberExistHelper(current.left, phoneNumber);
        }
        return false;
    }
    public boolean doesNumberExist(String phoneNumber) {
        return doesNumberExistHelper(root, phoneNumber);
    }

    /**
     * Returns the string representation of the BSFamilyTree
     */
    private StringBuilder toString(FamilyTreeNode root, int i) {
    	FamilyTreeNode current = root;
    	StringBuilder r = new StringBuilder() ;
    	for (int j=0; j<i; j++) {
    		r.append("  ");
    		}
    	if (current==null) {
    		r.append("null\n");
    		} 
    	else {
    		r.append(current.getMembers().toString() + "\n");
    		r.append(toString(current.left,i+1));
    		r.append(toString(current.right,i+1));
    		}
    	return r;
    	}
    public String toString() {
        return toString(root,0).toString();
    }
}
