package midterm;

public class ListMatrix extends ListCollection<Integer> {
	  private int rows;
	  private int columns;

	  /**
	   * Initializes a `ListMatrix` with the specified number of rows and columns. By
	   * default, ALL elements are set to 0.
	   * 
	   * @param rows
	   * @param columns
	   */
	  public ListMatrix(int rows, int columns) {
		  super(rows);
		  this.rows = rows;
		  this.columns = columns;
		  for(int i = 0; i < rows; i++) {
			  for(int k = 0; k < columns; k++) {
				  super.addElem(i,k,0);
			  }
		  }
		  super.setNodeCount(rows*columns);
	  }

	  /**
	   * @return the number of rows
	   */
	  public int numRows() {
	    return this.rows;
	  }

	  
	  /**
	   * 
	   * @return the number of columns
	   */
	  public int numColumns() {
	    return this.columns;
	  }

	  /**
	   * Adds the `ListMatrix` to `ListMatrix other`, storing the result in the caller
	   * (this)
	   * 
	   * @throws IllegalArgumentException if dimensions do not properly coincide
	   * @param other
	   * @complexity Your big-o and supporting explanation here
	   * big-o: O(n^2) two for loops, a nested for loop makes the n^2 time complexity
l	   */
	  public void add(ListMatrix other) {
		  if(rows != other.numRows() || columns != other.numColumns()){
			  throw new IllegalArgumentException();
		  }
		  for(int b = 0; b < rows; b++) {
			  for(int a = 0; a < columns; a++) {
				  this.setElem(b,a, (this.getElem(b,a)+other.getElem(b,a)));
			  }
		  }
	  }

	  /**
	   * Returns the transpose of the matrix
	   * 
	   * @param matrix
	   * @return matrix transpose
	   */
	  public static ListMatrix transpose(ListMatrix matrix) {
		  ListMatrix t = new ListMatrix(matrix.columns, matrix.rows);
		  for(int b = 0; b < matrix.rows; b++) {
			  for(int a = 0; a < matrix.columns; a++) {
				  t.setElem(a,b, matrix.getElem(b,a));
			  }
		  }
		  return t;
	  }

	  /**
	   * Multiplies the `ListMatrix` with `ListMatrix other`, returning the result as
	   * a new `ListMatrix.
	   * 
	   * @throws IllegalArgumentException if dimensions do not properly coincide
	   * @param other
	   * @return
	   */
	  public ListMatrix multiply(ListMatrix other) {
			ListMatrix LM = new ListMatrix(this.rows, other.numColumns());
		  if(this.columns != other.numRows()){
			  throw new IllegalArgumentException();
		  }
		  int sum = 0;
		  for(int b = 0; b < this.rows; b++) {
			  for(int a = 0; a < other.numColumns(); a++) {
				  for(int i = 0; i < this.columns; i++) {
				  sum += this.getElem(b,i) * other.getElem(i,a);
				  }
				  LM.setElem(b,a, sum);
				  sum = 0;
			  }
		  }
		  this.setNodeCount(this.rows * other.numColumns());
		  return LM;
	  }

}
