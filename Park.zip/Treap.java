import java.util.Random;
import java.util.*;

public class Treap<E extends Comparable<E>> {
	//Treap Data fields
	private Random priorityGenerator;
	private Node<E> root;
	
	//Node class
	private static class Node<E>{
		public E data;
		public int priority;
		public Node<E> left;
		public Node<E> right;
		
		public Node(E data, int priority) {
			if (data == null) {
				throw new IllegalStateException();
			}
			this.data = data;
			this.priority = priority;
			left = null;
			right = null;
			
		}
		//methods
		public Node<E> rotateRight(){
			if(this.left == null) {
				throw new IllegalStateException();
			}
			Node<E> temp = this.left;
			this.left = this.left.right;
			temp.right = this;
			return temp;
		
		}
		
		public Node<E> rotateLeft(){
			if(this.right == null) {
				throw new IllegalStateException();
			}
			Node<E> temp = this.right; 
			this.right = this.right.left; 
			temp.left = this;
			return temp;
		}
		
		public String toString() {			
			StringBuilder r = new StringBuilder() ;
			r.append("(key="+data.toString()+ ", priority=" + priority + ")");
			return r.toString();
		}
	}
	
	//Treap constructors
	public Treap() {
		root = null;
		priorityGenerator = new Random();
	}
	public Treap(long seed) {
		root = null;
		priorityGenerator = new Random(seed);
	}
	
	public boolean add(E key) {
		int p = priorityGenerator.nextInt();
		return add(key, p);
	}
	
	private void reheap(Node<E> N, Stack<Node <E>> s) {
		Node<E> temp = s.pop();
		while(!s.isEmpty()) {
			if(temp.priority < N.priority) {
				if(temp.data.compareTo(N.data) > 0) {
					N = temp.rotateRight();
				}
				else {
					N = temp.rotateLeft();
				}
			}
			if(!s.isEmpty()) {
				if(s.peek().left == N) {
					s.peek().left = N;
				}
				else {
					s.peek().right = N;
				}
			}
			else {
				this.root = N;
			}
			break;
		}
    } 
	
	public boolean add(E key, int priority) {
		Stack<Node <E>> s = new Stack<Node <E>>();
		Node<E> N = new Node<E>(key, priority);
		if (root == null) {
			root= N;
			return true;
		}
		else {	
			Node<E> current = root;
			Node<E> prev = null;
			while(current != null) {
				if (N.data.compareTo(current.data) == 0 || N.priority == current.priority) {
					return false;
				}
				if(N.data.compareTo(current.data) < 0) {
					if(current.left == null){
						current.left = N;
						s.push(current);
						s.push(N);
						break;
					}
					else {
						prev = current;
						s.push(current);
						current = current.left;
					}
				} 
				else if(N.data.compareTo(current.data) > 0) {
					if(current.right == null) {
						current.right = N;
						s.push(current);
						s.push(N);
						break;
					}
				}
				else {
					prev = current;
					s.push(current);
					current = current.right;
				}
			}
		}
		reheap(N, s);
		return true;
	}

	private boolean deleteHelper(Node<E> current, E  key) {
		if (current == null) {
			return false;
		}
		else {
			if(current.data.compareTo(key) < 0) {
				return deleteHelper(current.right, key);
			}
			else {
				if(current.data.compareTo(key) > 0) {
					return deleteHelper(current.left,key);
				}
				else {
					if(current.right == null) {
						current = current.left;
					}
					else if(current.left == null) {
						current = current.right;
					}
					else {
						if(current.priority < current.right.priority) {
							current = current.rotateRight();
							return deleteHelper(current.right, key);
						}
						else {
							current = current.rotateLeft();
							return deleteHelper(current.left, key);
						}
					}
				}
			}
		}
		return true;
	}
	
	public boolean delete(E key) {
		return deleteHelper(root, key);
	
	}
	
	private boolean find(Node<E> root, E key) {
		Node<E> current = root;
		if(current == null) {
			return false;
		}
		if(key.compareTo(root.data) == 0) {
			return true;
		}
		else if(key.compareTo(root.data) < 0 ){
			return find(root.left,key);
		}
		else {
			return find(root.right,key);
		}
	}
	
	public boolean find(E key){
		return find(root, key);
	}
	
	private StringBuilder toString(Node<E> current, int i) {
		StringBuilder r = new StringBuilder() ;
		for (int j=0; j<i; j++) {
			r.append(" ");
		}
		if (current==null) {
			r.append("null\n");
		} 
		else {
			r.append("(key="+current.data.toString()+ ", priority=" + current.priority + ")"+ "\n");
			r.append(toString(current.left,i+1));
			r.append(toString(current.right,i+1));
		}
		return r;
	}
	
	public String toString() {
		return toString(root,0).toString();
	}
	
	public static void main(String args[]) {
		Treap<Integer> tree = new Treap<Integer>();
		
		tree.add(4,19);
		tree.add(2 ,31);
		tree.add(6 ,70);
		tree.delete(6);
//		tree.add(3 ,12);
//		tree.add(5 ,83);
//		tree.add(7 ,26);

		System.out.println(tree);

	}
}
