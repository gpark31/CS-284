import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class treapTest {

	@Test
	void testRotate() {
		Node<String> tree = new Node<String>("q", 90);
		assertThrows(IllegalStateException.class, () -> tree.rotateRight());
		assertThrows(IllegalStateException.class, () -> tree.rotateLeft());
		tree.left = new Node<String>("a", 80);
		tree.left.left = new Node<String>("n", 30);
		tree.left.right = new Node<String>("w", 1);
		
		tree.right = new Node<String>("b", 70);
	}
	@Test
	void testFind() {
		Treap<String> tree = new Treap<String>();
		assertEquals(tree.find("q"), false);
		tree.add("q", 9);
		assertEquals(tree.find("q"), true);
		assertEquals(tree.find("s"), false);
	}
	@Test

	void testAdd() {
		Treap<String> tree = new Treap<String>();
		assertEquals(tree.add("q", 9), true);
		assertEquals(tree.add("q", 9), false);
		assertEquals(tree.add("s", 10), true);

		//reheap does not work
	}


}
