
public class Complexity {

	//methods
	public static void method1(int n) {
		//O(n^2)
		int counter = 0;
		for (int i = 0; i < n; i++) {
			for(int j = 0; j < n; j++) {
				//System.out.println("O(n^2)");
				counter++;
			}
		}
		System.out.println("Method 1:" + counter);
	}
	
	public static void method2(int n) {
		//O(n^3)
		int counter = 0;
		for (int i = 0; i < n; i++) {
			for(int j = 0; j <n; j++) {
				for(int b = 0; b < n; b++) {
					//System.out.println("O(n^3)");
					counter++;
				}
			}
		}
		System.out.println("Method 2:" + counter);
	}
	
	public static void method3(int n) {
		//O(log n)
		int counter = 0;
		for (int i = 1; i < n; i *= 2) {
			//System.out.println("O(log n)");
			counter++;
		}
		System.out.println("Method 3:" + counter);

	}
	
	public static void method4(int n) {
		//O(n log n)
		int counter = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 1; j < n ; j*=2) {
				//System.out.println("O(n log n)");
				counter++;
			}
		}
		System.out.println("Method 4:" +counter);

	}
	public static void method5(int n) {
		//O(log log n) 
		int counter = 0;
		for(int i = n; i > 1; i = (int)Math.sqrt(i)) {
			counter++;
		}
		System.out.println("Method 5:" + counter);
	}
	
	public static int method6(int n) {
		//O(2^n)
		int ans = 0; 
		if (n == 0) {
			return 1;
		}
		for(int i = 0; i < 2; i++) {
			ans += method6(n-1);
		}
		return ans;
	}
	
}
