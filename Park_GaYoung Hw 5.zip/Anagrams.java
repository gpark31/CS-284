//package anagrams;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Iterator;
/*
 * {2 = a, 3 = b, 5 = c, 7 = d, 11 = e, 13 = f, 17 = g, 19 = h, 23 = i, 29 = j, 
			31 = k, 37 = l, 41 = m, 43 = n, 47 = o, 53 = p, 59 = q, 61 = r, 67 = s, 
			71 = t, 73 = u, 79 = v, 83 = w, 89 = x, 97 = y, 101 = z};
 */
public class Anagrams {
	final Integer[] primes =  
			{2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 
			31, 37, 41, 43, 47, 53, 59, 61, 67, 
			71, 73, 79, 83, 89, 97, 101};
	Map<Character,Integer> letterTable;
	Map<Long,ArrayList<String>> anagramTable;
	
/* builds the hash table made of a list of integers */
	public void buildLetterTable() {
		letterTable = new HashMap<Character, Integer>();
		for (int i = 97; i < 123; i++) {
			letterTable.put((char)i, primes[i-97]);
		}
	}

	public Anagrams() {
		buildLetterTable();
		anagramTable = new HashMap<Long,ArrayList<String>>();
	}
	
/* adds the string s into the Anagram with its key
 * @param string s that needs to be added
 */
	public void addWord(String s) {
		ArrayList<String> str = new ArrayList<>();
		if(null != anagramTable.get(myhashcode(s))){
			str = anagramTable.get(myhashcode(s));
		}
		str.add(s);
		anagramTable.put(myhashcode(s), str);	
	}
	
/* compute the hash code of the string
 * @param string that needs its hashcode
 */
	public long myhashcode(String s) {
		long l = 1;
		for(int i = 0; i < s.length(); i ++) {
			l = l * letterTable.get(s.charAt(i));
		}
		return l;
	}
	
	public void processFile(String s) throws IOException {
		FileInputStream fstream = new FileInputStream(s);
		BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
		String strLine;
		while ((strLine = br.readLine()) != null)   {
		  this.addWord(strLine);
		}
		br.close();
	}
/* 
 * @param Arraylist of elements 
 * @return ArrayList of the largest elements in the Anagram
 */
	public ArrayList<Map.Entry<Long,ArrayList<String>>> getMaxEntries() {
	    // find the maximum
		ArrayList<Entry<Long, ArrayList<String>>> al = null;
		int a = 0;
		for(Map.Entry<Long, ArrayList<String>> entry: anagramTable.entrySet()) {
			if(entry.getValue().size() > a) {
				al = new ArrayList<>();
				al.add(entry);
				a = entry.getValue().size();
			}
		}
		return al;

	}

	public static void main(String[] args) {
		Anagrams a = new Anagrams();

		final long startTime = System.nanoTime();    
		try {
			a.processFile("words_alpha.txt");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		ArrayList<Map.Entry<Long,ArrayList<String>>> maxEntries = a.getMaxEntries();
		final long estimatedTime = System.nanoTime() - startTime;
		final double seconds = ((double) estimatedTime/1000000000);
		System.out.println("Elapsed Time: "+ seconds);
		System.out.println("List and Key of max anagrams: "+ maxEntries);
	}
}
