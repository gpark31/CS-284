import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class AnagramTest {
	
	@Test
	void testMyHashCode() {
		Anagrams a = new Anagrams();
		assertEquals(a.myhashcode("alerts"), 236204078);
		assertEquals(a.myhashcode("alters"), 236204078);
		assertEquals(a.myhashcode("artels"), 236204078);
		assertEquals(a.myhashcode("estral"), 236204078);
		assertEquals(a.myhashcode("laster"), 236204078);

		assertEquals(a.myhashcode("a"), 2);
		assertEquals(a.myhashcode("z"), 101);

	}
	@Test
	void testAddWord() {
		Anagrams a = new Anagrams();
		a.addWord("alerts");

		assertEquals(a.getMaxEntries().toString(), "[236204078=[alerts]]");
		a.addWord("alters");
		assertEquals(a.getMaxEntries().toString(), "[236204078=[alerts, alters]]");
		a.addWord("artels");
		assertEquals(a.getMaxEntries().toString(), "[236204078=[alerts, alters, artels]]");
		a.addWord("estral"); 
		assertEquals(a.getMaxEntries().toString(), "[236204078=[alerts, alters, artels, estral]]");

	}
	@Test
	void testGetMaxEntries() {
		Anagrams a = new Anagrams();
		a.addWord("alerts");
		a.addWord("alters");
		a.addWord("artels");
		assertEquals(a.getMaxEntries().toString(), "[236204078=[alerts, alters, artels]]");

		a.addWord("abscd");
		a.addWord("bdsac");
		a.addWord("dcsba");
		a.addWord("scdba");
		assertEquals(a.getMaxEntries().toString(), "[14070=[abscd, bdsac, dcsba, scdba]]");

	}
}
