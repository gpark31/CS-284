import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class IDLListTest {

	@Test
	void testAdd() {
		IDLList<Integer> test = new IDLList<Integer>();
		assertEquals(test.add(0,1), true);
		assertEquals(test.add(1,2), true);
		assertEquals(test.add(2,3),true);
		assertEquals(test.add(0,4),true);
		assertEquals(test.add(2,6),true);
		assertEquals(test.add(9),true);
		assertEquals(test.add(-1),true);
		assertEquals(test.toString(), "[-1,9,4,1,6,2,3,]");
		assertThrows(IllegalStateException.class, () -> test.add(10,10));
		assertThrows(IllegalArgumentException.class, () -> test.add(-1,10));
	}
	@Test
	void testAdd1() {
		IDLList<Integer> test = new IDLList<Integer>();
		test.add(0,1);
		assertEquals(test.toString(), "[1,]");
		test.add(1,2);
		assertEquals(test.toString(), "[1,2,]");
		test.add(2,3);
		assertEquals(test.toString(),"[1,2,3,]");
		test.add(0,4);
		assertEquals(test.toString(),"[4,1,2,3,]");
		test.add(2,6);
		assertEquals(test.toString(),"[4,1,6,2,3,]");
		test.add(9);
		assertEquals(test.toString(),"[9,4,1,6,2,3,]");
		test.add(-1);
		assertEquals(test.toString(),"[-1,9,4,1,6,2,3,]");
	}
	@Test
	void testAppend() {
		IDLList<Integer> test = new IDLList<Integer>();
		assertEquals(test.append(9), true);
		assertEquals(test.append(-1),true);
		
		assertEquals(test.toString(), "[9,-1,]");
		test.append(2);
		assertEquals(test.toString(), "[9,-1,2,]");
	}
	@Test
	void getTest() {
		IDLList<Integer> test = new IDLList<Integer>();
		test.add(0,1);
		test.add(1,2);
		test.add(2,3);
		test.add(0,4);
		test.add(2,6);
		assertEquals(test.toString(),"[4,1,6,2,3,]");
		assertEquals(test.get(0),4);
		assertEquals(test.get(1),1);
		assertEquals(test.get(2),6);
		assertEquals(test.get(3),2);
		assertEquals(test.get(4),3);
		assertThrows(IllegalStateException.class, () -> test.get(10));
		assertThrows(IllegalStateException.class, () -> test.get(-1));
	}
	@Test
	void getHeadLast() {
		IDLList<Integer> test = new IDLList<Integer>();
		assertThrows(IllegalStateException.class, () -> test.getHead());
		assertThrows(IllegalStateException.class, () -> test.getLast());
		test.add(0);
		assertEquals(test.getHead(),0);
		assertEquals(test.getLast(),0);
		test.add(1);
		assertEquals(test.getHead(),1);
		assertEquals(test.getLast(),0);
		test.add(2,3);
		assertEquals(test.getHead(),1);
		assertEquals(test.getLast(), 3);
		assertEquals(test.toString(),"[1,0,3,]");
	}
	@Test
	void testSize() {
		IDLList<Integer> test = new IDLList<Integer>();
		assertEquals(test.size(), 0);
		test.add(0,1);
		assertEquals(test.size(), 1);
		test.add(1,2);
		assertEquals(test.size(), 2);
		test.add(2,3);
		assertEquals(test.size(), 3);
		test.add(0,4);
		assertEquals(test.size(), 4);
		test.add(2,6);
		assertEquals(test.size(), 5);
		assertEquals(test.toString(), "[4,1,6,2,3,]");

	}
	@Test
	void testRemove() {
		IDLList<Integer> test = new IDLList<Integer>();
		assertThrows(IllegalStateException.class, () -> test.remove());
		test.add(0,1);
		assertEquals(test.remove(), 1);
		assertEquals(test.toString(), "[]");

	}
	@Test
	void testRemoveLast() {
		IDLList<Integer> test = new IDLList<Integer>();
		test.add(2);
		test.add(0);
		test.add(4);
		assertEquals(test.removeLast(), 2);
		assertEquals(test.removeLast(), 0);
		assertEquals(test.removeLast(), 4);
		assertThrows(IllegalArgumentException.class, () -> test.removeLast());
		assertEquals(test.toString(), "[]");

	}
	@Test
	void testRemoveAt() {
		IDLList<Integer> test = new IDLList<Integer>();
		test.add(2);
		test.add(0);
		test.add(4);
		test.add(5);
		test.add(6);
		test.add(9);
		test.add(11);

		assertThrows(IllegalArgumentException.class, () -> test.removeAt(-1));
		assertThrows(IllegalStateException.class, () -> test.removeAt(10));		
		assertEquals(test.removeAt(0), 11);
		assertEquals(test.removeAt(5), 2);
		assertEquals(test.removeAt(2), 5);
		assertEquals(test.removeAt(2), 4);
		assertEquals(test.toString(),"[9,6,0,]");

	}
	@Test
	void testRemoveB(){
		IDLList<Integer> test = new IDLList<Integer>();
		test.add(2);
		test.add(0);
		test.add(4);
		test.add(5);
		test.add(6);
		test.add(9);
		test.add(11);
		
		assertEquals(test.remove(2), true);
		assertEquals(test.remove(11), true);
		assertEquals(test.remove(3), false);
		assertEquals(test.remove(4), true);
		assertEquals(test.toString(), "[9,6,5,0,]");
	}

	@Test
	void testToString() {
		IDLList<Integer> test = new IDLList<Integer>();
		assertEquals(test.toString(), "[]");
		test.add(2);
		test.add(0);
		test.add(4);
		test.add(5);
		assertEquals(test.toString(), "[5,4,0,2,]");
	}
	
}
