
import java.util.ArrayList;

public class IDLList<E> {
	//Node
	private static class Node<E>{
		//data fields
		private E data;
		private Node<E> next;			
		private Node<E> prev;
		
		//constructors
		public Node (E elem) {				
			super();
			data = elem;
			this.next = null;
		}
			
		public Node(E elem, Node<E> prev, Node<E> next){
			super();
			data = elem;
			this.prev = prev;
			this.next = next;
			}
		}
		
	//data fields
	private Node<E> head;
	private Node<E> tail;
	private int size;
	private ArrayList<Node<E>> indices;
	
	public IDLList() {
		head = null;
		tail = null;
		size = 0;
		indices = new ArrayList<Node<E>>();
		
	}
	//indices
	public boolean add(int index, E elem) {

		if (index > size) {
			throw new IllegalStateException();
		}
		else if(index < 0) {
			throw new IllegalArgumentException();
		}
		else if(size == 0) {
			Node<E> node = new Node<E>(elem);
			head = node;
			tail = head;
			indices.add(0, node);
		}
		else if(index == 0) {
			Node<E> node = new Node<E>(elem, null, head);
			head = node;
			node.next.prev = node;
			indices.add(0,node);
		} 
		else if (index == size) {
			Node<E> node = new Node<E>(elem, tail, null);
			tail = node;
			node.prev.next = node;
			indices.add(node);
		}
		else {
			Node<E> node = new Node<E>(elem, indices.get(index).prev, indices.get(index));
			node.prev.next = node;
			node.next.prev = node;
			indices.add(index, node);
		}
		size++;
		return true;
	}
	//indices
	public boolean add(E elem) {
		add(0, elem);
		return true;
	}
	//indices
	public boolean append(E elem) {
		add(indices.indexOf(tail)+1,elem);
		return true;
	}
	
	public E get(int index) {
		Node<E> current = head;
		if (index >=size || index < 0) {
			throw new IllegalStateException();
		}
		else {
			current = indices.get(index);
		}
		return current.data;
	}
	
	public E getHead() {
		if(head == null) {
			throw new IllegalStateException();
		}
		return head.data;
	}
	
	public E getLast () {
		if(tail == null) {
			throw new IllegalStateException();
		}
		return tail.data;
	}
	
	public int size() {
		return size;
	}
	//indices
	public E remove () {
		return removeAt(0);
	}
	
	//indices
	public E removeLast () {
		return removeAt(size-1);
	}
	
	//indices
	public E removeAt (int index) {
		Node<E> temp;
		//implement first
		if (index >= size) {
			throw new IllegalStateException();
		}
		else if(index < 0) {
			throw new IllegalArgumentException();
		}
		else if(size == 1) {
			temp = head;
			head = null;
			tail = null;
			indices.remove(0);
		}
		else if(index == 0) {
			temp = head;
			head = head.next;
			head.prev = null;
			indices.remove(0);
		} 
		else if (index == size-1) {
			temp = tail;
			tail= tail.prev;
			tail.next = null;
			indices.remove(index);
		}
		else {			
			temp = indices.get(index);
			temp.prev.next = temp.next;
			temp.next.prev = temp.prev;
			indices.remove(index);

		}
		size--;
		return temp.data;
	}
	//indices
	public boolean remove (E elem) {
		Node<E> current = head;
		int i = 0;
		while(current != null) {
			if(current.data == elem) {
				removeAt(i);
				return true;
			}
			current = current.next;
			i++;
		}
		return false;
	}
	
	public String toString() {
		StringBuilder s = new StringBuilder();
		Node<E> current = head;
		s.append("[");
		while (current!=null) {
			s.append(current.data.toString()+",");
			current = current.next;
		}
		s.append("]");
		return s.toString();
	}
}
